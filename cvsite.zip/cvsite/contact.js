

//contact form//
function sendMail() {
  var params = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    subject: document.getElementById("subject").value,
    message: document.getElementById("message").value,
  };

    const serviceID = "service_hfhm0cm";
    const templateID = "template_gddsdyl";

  emailjs
    .send(serviceID, templateID, params)
    .then((res) => {
      document.getElementById("name").value = "";
      document.getElementById("email").value = "";
      document.getElementById("phone").value = "";
      document.getElementById("subject").value = "";
      document.getElementById("message").value = "";
      coluse.log(res);
      alert("Mesajınız başarıyla gönderildi");
    })
    .catch((err) => console.log(err));
}
